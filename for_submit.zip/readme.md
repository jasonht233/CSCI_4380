   Recommended Fishing Rivers And Streams (River_data)
    https://data.ny.gov/Recreation/Recommended-Fishing-Rivers-And-Streams/jcxg-7gnm

    Accessible Outdoor Recreation Destinations
    https://data.ny.gov/Recreation/Accessible-Outdoor-Recreation-Destinations/pt2v-9a3h

    Liquor Authority Quarterly List of Active linceses

    https://data.ny.gov/Economic-Development/Liquor-Authority-Quarterly-List-of-Active-Licenses/hrvs-fxs2

    
    National Register of Historic Places
    https://data.ny.gov/Recreation/National-Register-of-Historic-Places/iisn-hnyv


    