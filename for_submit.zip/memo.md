Final project:


memebers:

    Bohan Wu (wub4)
    Haotian Zhang (zhangh20)
    Ruoyan Wu(wur7）
    Shenjin Li (lis17)
    
datasets:

    Recommended Fishing Rivers And Streams (River_data)
    https://data.ny.gov/Recreation/Recommended-Fishing-Rivers-And-Streams/jcxg-7gnm

    Accessible Outdoor Recreation Destinations
    https://data.ny.gov/Recreation/Accessible-Outdoor-Recreation-Destinations/pt2v-9a3h

    Liquor Authority Quarterly List of Active linceses

    https://data.ny.gov/Economic-Development/Liquor-Authority-Quarterly-List-of-Active-Licenses/hrvs-fxs2

    
    National Register of Historic Places
    https://data.ny.gov/Recreation/National-Register-of-Historic-Places/iisn-hnyv


plan:
        We would create an app which can combine the datasets of Fishing, Historic Places, Recreations to make up a list of destination which meets you requirement and interest for you to choose for your vacation .s